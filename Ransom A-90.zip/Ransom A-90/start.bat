python "ransom.py"
pause